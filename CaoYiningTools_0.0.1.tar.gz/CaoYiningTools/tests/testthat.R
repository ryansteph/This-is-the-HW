library(testthat)
library(CaoYiningTools)

test_check("CaoYiningTools")
